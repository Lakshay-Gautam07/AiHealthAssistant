export const MONGO_URI = 'mongodb+srv://sharmagauravxo:1UJgSEBGyRT9WcLo@cluster0.66dx9.mongodb.net/';
